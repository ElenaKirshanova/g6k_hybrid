
fn = "report00.txt"
newfn = "report000.txt"

with open(fn,"r") as readfile:
    with open(newfn, "w") as writefile:
        while True:
            line = readfile.readline()
            if not ("Warn" in line or "WARN" in line):
                writefile.write(line)
            if not line:
                break
