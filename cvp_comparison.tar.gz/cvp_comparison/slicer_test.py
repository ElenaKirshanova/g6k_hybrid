from fpylll.util import gaussian_heuristic
from fpylll import *
from g6k.siever import Siever
from g6k.utils.stats import dummy_tracer
from g6k.siever_params import SieverParams
from g6k.algorithms.pro_randslicer import pro_randslicer
from math import sqrt
from g6k.utils.util import load_cvp_instance
from copy import deepcopy
from DistEstColattice import DistEstDistEstColattice
from math import log, ceil
from fpylll import BKZ as fplll_bkz
from fpylll.algorithms.bkz2 import BKZReduction
import time, pickle

import warnings
from multiprocessing import Pool

warnings.filterwarnings('ignore')

def dot_product(a,b):
    return sum([a[i]*b[i] for i in range(len(a))])

def norm(a):
    return sqrt(dot_product(a,a))


#Use the simulator like BKZ 2.0
def draw_cvp_bound_simulation():
    return


def cvp_test(A,t, params, myparams):
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        close_vector = tuple([0]*A.ncols)
        sample_times = 1
        T_sieve = 0
        db_size = 0
        if(A.nrows == 1):
            T0 =time.time()
            #babai
            c = round(dot_product(t,A[0])/ dot_product(A[0],A[0]))
            close_vector = tuple([c*A[0][i] for i in range(A.ncols)])
            T_slicer = time.time() - T0
        elif(A.nrows <= 30):
            #CVP enumeration
            A = IntegerMatrix.from_matrix(A, int_type="mpz")
            T0 =time.time()
            close_vector = CVP.closest_vector(A,t)
            T_slicer = time.time() - T0
        else:
            #randomlized slicer
            # params = SieverParams(threads = 1,saturation_ratio = 1.)

            g6k = Siever(A,params)
            f = 0
            # print(g6k.M.B.nrows,g6k.M.B.ncols)
            close_vector,_,sample_times, T_sieve, T_slicer, db_size = pro_randslicer(g6k,t,dummy_tracer,f,verbose=False, )
    return close_vector, sample_times, T_sieve, T_slicer, db_size


def run_exp(n,index,A,t,myparams,tracer=None):
    params = SieverParams(threads = myparams["nthreads"] ,  saturation_ratio = 1. )#, saturation_ratio = 0.75)#, saturation_ratio = 1.,  db_size_factor = 5, default_sieve = "bgj1" )#, db_size_factor = 1.5 )


    print("{0: <10} | {1: <10} | {2: <15} | {3: <30} | {4: <15} | {5: <15} | {6: <15} | {7: <15} | {8: <15} | {9: <15}".format("dim", "index", "sample times", "estimated sample times", "T_pump (sec)", "T_slicer (sec)", "dt", "gh", "db_size", "satisfied vectors"))
    exp_results = []

    A = LLL.reduction(A)
    g6k = Siever(A,None)
    for blocksize in range(10, 5, 31):
        bkz = BKZReduction(g6k.M)
        par = fplll_bkz.Param(blocksize,
                                    strategies=fplll_bkz.DEFAULT_STRATEGY,
                                    max_loops=1)
        bkz(par)


    rr = [g6k.M.get_r(i, i) for i in range(n)]


    w, sample_times,T_pump, T_slicer, db_size = cvp_test(A,t, params, myparams)
    max_sample_times = ceil((16/13.)**(n//2.))


    gh = sqrt(gaussian_heuristic(rr))
    dt = sqrt(sum([(w[i] - t[i])**2 for i in range(len(t))]))
    # simDist = DistEstDistEstColattice([log(_)/2. for _ in rr[:n]], [n])

    print("{0: <10} | {1:<10} | {2: <15} | {3: <30} | {4: <15} | {5: <15} | {6: <15} | {7: <15} | {8: <15} | {9: <15}".format(n,index, sample_times, max_sample_times, round(T_pump,4), round(T_slicer,4), round(dt,3), round(gh,3), db_size, int(.5 * params.saturation_ratio * params.db_size_base ** n )))
    return [T_pump, T_slicer, dt, gh, db_size] 

# - - -
rngs = (55, 66, 5)
tours = 10
myparams = {
    "max_slicer_interations": 100,
    "proj_err_bound": 0.7,
    "saturation_scalar": 1.0,
    "nrand_fact": 10,
    "nthreads": 5
}
pool = Pool(processes = 2)

filename = f"prec_cvp_chal_{rngs}_{tours}.pkl"
loaded = False
try:
    with open(filename,"rb") as file:
        At_dict = pickle.load(file)
        loaded = True
    print("Precomputed challenges found.")
except FileNotFoundError:
    print("No precomputed challenges found.")
    At_dict = {}
    for n in range(rngs[0], rngs[1], rngs[2]):
        At_dict[n] = []
        for index in range(tours):
            A, t = load_cvp_instance(n)
            At_dict[n].append([A,t])
    with open(filename,"wb") as file:
        pickle.dump(At_dict,file)

tasks = {}
exp_results = {}
for n in range(rngs[0], rngs[1], rngs[2]):
    tasks[n] = []
    exp_results[n] = []
    for index in range(tours):
            exp_results[n].append( None )
            A, t = At_dict[n][index]
            tasks[n].append( 
                pool.apply_async( run_exp, (n,index,A,t,myparams,None) )
             )
            
for n in range(rngs[0], rngs[1], rngs[2]):
    for index in range(tours):
        exp_results[n][index] = tasks[n][index].get()

filename_exp = f"cvp_chal_pump__{rngs}_{tours}.pkl"
with open(filename_exp,"wb") as file:
        pickle.dump(exp_results,file)